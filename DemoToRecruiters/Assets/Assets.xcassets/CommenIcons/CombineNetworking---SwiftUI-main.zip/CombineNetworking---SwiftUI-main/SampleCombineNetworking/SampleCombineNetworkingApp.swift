//
//  SampleCombineNetworkingApp.swift
//  SampleCombineNetworking
//
//  Created by Sajjad Sarkoobi on 3.09.2022.
//

import SwiftUI

@main
struct SampleCombineNetworkingApp: App {
    var body: some Scene {
        WindowGroup {
            ProductView()
        }
    }
}
